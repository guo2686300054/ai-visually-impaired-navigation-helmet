#ifndef __HCSR04_H
#define __HCSR04_H

#define Trig_Port 	GPIOA
#define Trig_Pin 		GPIO_Pin_6
#define Trig_RCC		RCC_APB2Periph_GPIOA

#define Echo_Port 	GPIOA
#define Echo_Pin 		GPIO_Pin_5
#define Echo_RCC		RCC_APB2Periph_GPIOA
#include "stm32f10x.h"                

void HCSR04_Init(void);
uint16_t HCSR04_GetValue(void);
#endif 
