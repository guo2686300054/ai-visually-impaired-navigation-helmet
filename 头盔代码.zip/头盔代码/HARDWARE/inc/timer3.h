#ifndef _TIMER3_H
#define _TIMER3_H

void TIM3_ENABLE(void);
#endif
