#ifndef __ADC_H
#define	__ADC_H


#include "stm32f10x.h"

void Init_adc(void);
extern __IO uint16_t ADC_ConvertedValue[2];
#endif /* __ADC_H */

