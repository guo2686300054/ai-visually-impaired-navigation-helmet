#ifndef __SW_H
#define __SW_H	 
#include "sys.h"
#define PENWU PAout(12)

void SW_Init(void);//��ʼ��

		 				    
#endif
