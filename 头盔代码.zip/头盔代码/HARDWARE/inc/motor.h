#ifndef __MOTOR_H
#define __MOTOR_H	 
#include "sys.h"
#define MOTORA PAout(9)
#define MOTORB PAout(10)

void MOTOR_Init(void);//��ʼ��

		 				    
#endif
