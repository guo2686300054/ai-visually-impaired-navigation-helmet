#ifndef __RED_H
#define __RED_H			  	 
#include "sys.h"
#include "stdlib.h"	  
#define RED     GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_7)
void RED_Init(void);
#endif
