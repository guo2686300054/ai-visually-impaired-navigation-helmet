#ifndef __WS2812B_H
#define __WS2812B_H
#include "sys.h"
#define empty 0
#define green 1
#define red 2
#define blue 3
void delay_ns(u32 nus);
void send_code(u8 color);
#endif

