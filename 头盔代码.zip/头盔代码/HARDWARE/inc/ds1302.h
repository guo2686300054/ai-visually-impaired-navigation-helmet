#ifndef DS1202_H
#define DS1302_H
#include "stm32f10x.h"
#include "sys.h"
//DS1302���Ŷ���,�ɸ���ʵ����������޸Ķ˿ڶ���
#define DS1302_OutPut_Mode() {GPIOB->CRL &= 0xF0FFFFFF;GPIOB->CRL |= 0x03000000;}
#define DS1302_InPut_Mode()  {GPIOB->CRL &= 0xF0FFFFFF;GPIOB->CRL |= 0x08000000;}
 
#define DS1302_IN  PBin(6)
#define DS1302_OUT PBout(6)
#define DS1302_RST PBout(5)
#define DS1302_CLK PBout(7)
 
struct TIMEData
{
	u16 year;
	u8  month;
	u8  day;
	u8  hour;
	u8  minute;
	u8  second;
	u8  week;
};
extern struct TIMEData TimeData;
extern u8 readtime[15];
void DS1302_Init(void);
void DS1302_WriteByte(u8 addr,u8 data);
u8   DS1302_ReadByte(u8 addr);
void DS1302_WriteTime(void);
void DS1302_ReadTime(void);
void DS1302_GetTime(void);
 
#endif
