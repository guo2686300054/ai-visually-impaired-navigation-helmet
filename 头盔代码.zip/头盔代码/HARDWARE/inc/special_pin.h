#ifndef __SPECIAL_PIN_H
#define __SPECIAL_PIN_H
#include "sys.h"
void SPECIAL_PIN_Init(void);
#endif

