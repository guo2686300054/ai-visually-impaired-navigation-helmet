#include "usart4.h"
/* ���ڳ�ʼ�� */
 
void STM4_EVAL_COMInit(USART_InitTypeDef* USART_InitStruct)
{
  GPIO_InitTypeDef GPIO_InitStructure;
 
  /* Enable GPIO clock */
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);//GPIOAʹ��
 
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART4, ENABLE);//USART2ʱ��ʹ��
 
  /* Configure USART Tx as alternate function push-pull */
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;//���PA2
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOC, &GPIO_InitStructure);
 
  /* Configure USART Rx as input floating */
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;//����PA3
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
  GPIO_Init(GPIOC, &GPIO_InitStructure);
 
  /* USART configuration */
  USART_Init(UART4, USART_InitStruct);//USART2��ʼ��
    
  /* Enable USART */
  USART_Cmd(UART4, ENABLE);//ʹ��USART2
}

void USART4_Init (u32 baud)
{
	USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure; 
	
	USART_InitStructure.USART_BaudRate = baud;                  //������
  USART_InitStructure.USART_WordLength = USART_WordLength_8b;   //����λ����=8
  USART_InitStructure.USART_StopBits = USART_StopBits_1;        //1��ֹͣλ
  USART_InitStructure.USART_Parity = USART_Parity_No;           //û��У��λ
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
 
  STM4_EVAL_COMInit(&USART_InitStructure);
	
	
//���ݽ��յ�ʹ���ж�
  /* Enable the USARTz Interrupt */
  NVIC_InitStructure.NVIC_IRQChannel = UART4_IRQn;//ΪUSART2
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 3;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
	
  /* Enable the USARTz Receive Interrupt */
  USART_ITConfig(UART4, USART_IT_RXNE, ENABLE);//
}
void USART4_SendString (char *s)
{
	while(*s)
	{
		USART_SendData(UART4, *s++);
    while(USART_GetFlagStatus(UART4, USART_FLAG_TXE) == RESET)
    {
			
		}
	}
}
u8 USART4_RxCounter = 0;//�������ֵ
u8 USART4_RxBuffer[10];//���建����Ϊ10
 
void UART4_IRQHandler(void)
{
  if(USART_GetITStatus(UART4, USART_IT_RXNE) != RESET)//���ڽ����ж�
  {
    USART_ClearITPendingBit(UART4, USART_IT_RXNE);//�����־λ	
    USART4_RxBuffer[USART4_RxCounter++] = USART_ReceiveData(UART4);		
		if(USART4_RxCounter>6)//������յ��ֽڸ���
		{
			USART4_RxCounter=0;
		}
}	
}
