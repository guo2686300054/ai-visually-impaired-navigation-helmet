#include "stm32f10x.h"  
#include "main.h"     
#include "math.h"
#include "led.h"
#include "delay.h"      
#include "usart1.h"     
#include "usart2.h"     
#include "timer1.h"     
#include "timer2.h"     
#include "timer3.h"     
#include "timer4.h"     
#include "wifi.h"	    	
#include "beep.h"
#include "mqtt.h"       
#include "key.h"        
#include "oled.h"
#include "show.h"
#include "sw.h"
#include "adc.h"
#include "red.h"
#include "ws2812b.h"
#include "ds18b20.h"
#include "special_pin.h"

void TIM3_ENABLE(void)
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;            //����һ�����ö�ʱ���ı���
	NVIC_InitTypeDef NVIC_InitStructure;                          //����һ�������жϵı���
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);               //�����ж��������飺��2�� �������ȼ���0 1 2 3 �����ȼ���0 1 2 3		
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3,ENABLE);           //ʹ��TIM2ʱ��	
	TIM_DeInit(TIM3);                                             //��ʱ��2�Ĵ����ָ�Ĭ��ֵ	
	TIM_TimeBaseInitStructure.TIM_Period = 100-1; 	          //�����Զ���װ��ֵ
	TIM_TimeBaseInitStructure.TIM_Prescaler=7200-1;              //���ö�ʱ��Ԥ��Ƶ��
	TIM_TimeBaseInitStructure.TIM_CounterMode=TIM_CounterMode_Up; //���ϼ���ģʽ
	TIM_TimeBaseInitStructure.TIM_ClockDivision=TIM_CKD_DIV1;     //1��Ƶ
	TIM_TimeBaseInit(TIM3,&TIM_TimeBaseInitStructure);            //����TIM2
	
	TIM_ClearITPendingBit(TIM3,TIM_IT_Update);                    //�������жϱ�־λ
	TIM_ITConfig(TIM3,TIM_IT_Update,ENABLE);                      //ʹ��TIM2����ж�    
	TIM_Cmd(TIM3,ENABLE);                                         //��TIM2                          
	
	NVIC_InitStructure.NVIC_IRQChannel=TIM3_IRQn;                 //����TIM2�ж�
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=3;       //��ռ���ȼ�2
	NVIC_InitStructure.NVIC_IRQChannelSubPriority=0;              //�����ȼ�0
	NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;                 //�ж�ͨ��ʹ��
	NVIC_Init(&NVIC_InitStructure);                               //�����ж�
}
u16 ADC_ConvertedValueLocal;
float ADC_ConvertedValueLoca2;
u16 PreReadData;
u16 ReadData;
u16 data[50];
u16 max;
u16 min;
u16 mid;
u8 heart_valid;
u8 pre_heart_valid;
u8 heart_count;
u16 time_count;
u16 firsttime;
u16 secondtime;
u16 IBI;
u8 BPM;

uint16_t FindMin(uint16_t arr[], uint8_t len) 
{
    uint16_t min = arr[0];
	  uint8_t i;
    for (i= 1; i < len; i++) {
        if (arr[i] < min) {
            min = arr[i];
        }
    }
    return min;
}
 
uint16_t FindMax(uint16_t arr[], uint8_t len) 
{
    uint16_t max = arr[0];
	uint8_t i = 1;
    for (i = 1; i < len; i++) {
        if (arr[i] > max) {
            max = arr[i];
        }
    }
    return max;
}
void heart_test(u16 heart_datain,u8 index)
{
	PreReadData = ReadData;
	ReadData = heart_datain;
  if((ReadData - PreReadData) < 500)    // �˳�ͻ�������źŸ���
    data[index] = ReadData;	// ��仺������	
  if(index >= 49)
  {			
    // ͨ�����������ȡ�����źŵĲ��塢����ֵ���������м�ֵ��Ϊ�ж��ο���ֵ
    max = FindMax(data, 50);
    min = FindMin(data, 50);
    mid = (max + min)/2;
  }	
	pre_heart_valid = heart_valid;
	heart_valid = (ReadData>mid) ? 1 : 0;
	if(pre_heart_valid == 0 && heart_valid == 1)
	{
		heart_count++;
		heart_count%=2;
		if(heart_count==1)
		{
			firsttime = time_count;
		}
		if(heart_count==0)
		{
			secondtime = time_count;
			time_count=0;
      if((secondtime > firsttime))
      {
        IBI = (secondtime - firsttime) * 23;	// ������������������ʱ�䣬�õ� IBI
        BPM = 60000 / IBI;  // ͨ�� IBI �õ�����ֵ BPM  
        if (BPM > 200)    //����BPM�����ʾֵ
          heart_data = 200;	 				
        else if (BPM < 30)    //����BPM�����ʾֵ
          heart_data=30;
				else 
					heart_data=BPM;
      }
		}
	}
}

void TIM3_IRQHandler(void)
{
	u8 key;
	u8 i;
	static u8 key_count=0;
	static u16 adc_count=0;
	static u16 show_count=0;
	static u16 temp_count=0;
	static u8 ALI_count=0;      //�������ϴ�����
	static u8 HEART_count=0;    //���ʼ���
	static u8 heart_co=0;
	static u8 pre_weixian_status;   //��һ������״̬
	static u8 pre_light_status;
	static float light_zong;
	if(TIM_GetITStatus(TIM3, TIM_IT_Update) != RESET)
  { 
		ALI_count++;		
    //����������
		if(ALI_count>40)
		{
			mqtt_connect();
			ALI_count=0;
		}
		
		//����
		key_count++;
		if(key_count>=10)
		{
			key_count=0;
      key=KEY_Scan(0);
      if(key==KEY0_PRES)
		  {
				show_mode+=1;
				if(show_mode>=4)show_mode=0;
				OLED_Clear();
				if(show_mode==0)page_one();
				else if(show_mode==1)page_two();
				else if(show_mode==2)page_three();
				else if(show_mode==3)page_four();
		  }
			else if(key==KEY1_PRES)
			{
        if(show_mode==1)
				{
					send_status=1;
				}
				else tiaojie_status=!tiaojie_status;
			}
			else if(key==KEY2_PRES)
			{
				if(show_mode==2)
				{
					if(tiaojie_status==0)zhangai_yuzhi+=1;
					else zhangai_yuzhi+=10;
				}
				else if(show_mode==3)
				{
					if(tiaojie_status==0)light_yuzhi+=1;
					else light_yuzhi+=10;					
				}
			}
			else if(key==KEY3_PRES)
			{
				if(show_mode==2)
				{
					if(tiaojie_status==0)zhangai_yuzhi-=1;
					else zhangai_yuzhi-=10;
				}
				else if(show_mode==3)
				{
					if(tiaojie_status==0)light_yuzhi-=1;
					else light_yuzhi-=10;					
				}			
			}
		}		
		//������ǿ��
		adc_count++;
		ADC_ConvertedValueLoca2=(float)ADC_ConvertedValue[1]/4096;
		light_zong+=ADC_ConvertedValueLoca2;
		if(adc_count>=50)       //500ms����һ�μ���
		{
			adc_count=0;
			light_data=2000-light_zong/50*2000 ;//�������ǿ����ƽ��
			if(light_data<=light_yuzhi)light_status=1;
			else light_status=0;
			if(light_status!=pre_light_status)
			{
				if(light_status==0)dengdai_status=2;
				else dengdai_status=1;
			}
		  if(dengdai_status==1)
		  {
		  	dengdai_status=0;
        LED0=0;
	      delay_us(310);	    //��������ǰ����300us���ϵĸ�λ����
	      for(i=0;i<3;i++)
        {
	      	send_code(red);
	      }	
	      LED0=0;
        delay_us(310);			
		  }
		  else if(dengdai_status==2)
		  {
		  	dengdai_status=0;
        LED0=0;
	      delay_us(310);	    //��������ǰ����300us���ϵĸ�λ����
	      for(i=0;i<3;i++)
        {
	      	send_code(empty);
	      }	
	      LED0=0;
        delay_us(310);				
		  }
		  else
		  {
		  	
		  }
		  	light_zong=0;
		  }		
		//���ʼ���㷨
		heart_co++;
		if(heart_co==2)
		{
			heart_co=0;
		  time_count++;
	    ADC_ConvertedValueLocal=ADC_ConvertedValue[0];
      heart_test(ADC_ConvertedValueLocal,HEART_count);
		  HEART_count++;
		  if(HEART_count>=50)HEART_count=0;
		}	
				
		//����¶�
		temp_count++;
		if(temp_count>=100)
		{
			temp_count=0;
			temp=DS18B20_Get_Temp();
		}	

		if(RED)people_status=1;
		else people_status=0;
		
		if(zhangai_juli<=zhangai_yuzhi||people_status)
		{
			weixian_status=1;
		}
		else
		{
			weixian_status=0;
		}
		
		
		if(pre_weixian_status!=weixian_status&&weixian_status)
		{
			yuyin_status=1;
		}		

		
//		//�����¶ȼ��
//		if(TEMP_count>=50)
//		{
//			TEMP_count=0;
//		  temp=DS18B20_Get_Temp();
//		}	
//		//�ⲿ���ݼ��
//    adc1=(float)ADC_ConvertedValue[0]/4096;
//		adc2=(float)ADC_ConvertedValue[1]/4096;
//		adc3=(float)ADC_ConvertedValue[2]/4096;
//		smooth_zong=smooth_zong+adc1;
//		co_zong=co_zong+adc2;
//		fire_zong=fire_zong+adc3;
//		if(ADC_count>=50)
//		{
//			ADC_count=0;
//			smooth_data=smooth_zong/50*10000;
//			co_data=co_zong/50*2000;
//			fire_data=100-fire_zong/50*100;
//			if(fire_data>=50)fire_status=1;
//			else fire_status=0;
//			smooth_zong=0,co_zong=0,fire_zong=0;
//		}
//		//�����ж�
//		if(smooth_data>=smooth_yuzhi||temp>=temp_yuzhi||co_data>=co_yuzhi||fire_status)
//		{
//			baojing_status=1;
//		}
//		else 
//		{
//			baojing_status=0;
//		}
//		
//		if(baojing_status)BEEP=1,LED=1;
//		else BEEP=0,LED=0;
//		if(fire_status)LIGHT=1;
//		else LIGHT=0;
//		
//		if(smooth_data>=smooth_yuzhi&&fire_status)
//		{
//			miehuo_status=1;
//		}
//		else miehuo_status=0;
////		PENWU=1;
//		if(miehuo_status)PENWU=1;
//		else PENWU=0;
		
		//������������ʾ
		show_count++;
		if(show_count>=50)
		{
			show_count=0;
      if(show_mode==0)
			{
				OLED_ShowNum(72,0,zhangai_juli,3,16);
				OLED_ShowNum(88,6,heart_data,3,16);
				OLED_ShowNum(72,4,temp/10,3,16);
		    OLED_ShowNum(104,4,temp%10,1,16);
		    if(people_status)
		    {
			    OLED_ShowCHinese(84,2,8);OLED_ShowCHinese(100,2,4);
	  	  }
		    else
		    {
			    OLED_ShowCHinese(84,2,9);OLED_ShowCHinese(100,2,4);
		    }
			}
			else if(show_mode==1)
			{
        if(send_status)
				{
					OLED_ShowCHinese(84,0,24);OLED_ShowCHinese(100,0,25);
				}
				else
				{
					OLED_ShowCHinese(84,0,26);OLED_ShowCHinese(100,0,27);					
				}	
        OLED_ShowNum(72,2,light_data,4,16);   				
			}
			else if(show_mode==2)
			{
				OLED_ShowNum(44,4,zhangai_yuzhi,3,16);
			}
			else if(show_mode==3)
			{
				OLED_ShowNum(36,4,light_yuzhi,4,16);
			}
			pre_weixian_status=weixian_status;
			pre_light_status=light_status;
		}
    TIM_ClearITPendingBit(TIM3, TIM_IT_Update);      //���TIM3����жϱ�־ 	
	}
}
