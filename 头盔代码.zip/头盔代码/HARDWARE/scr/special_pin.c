#include "special_pin.h"
#define      TM1668_APBxClock_FUN    RCC_APB2PeriphClockCmd

#define      TM1668_RCC_DIO          RCC_APB2Periph_GPIOC
#define      TM1668_DIO_PORT         GPIOC
#define      TM1668_DIO_PIN          GPIO_Pin_13

#define      TM1668_RCC_CLK          RCC_APB2Periph_GPIOC
#define      TM1668_CLK_PORT         GPIOC
#define      TM1668_CLK_PIN          GPIO_Pin_14

#define      TM1668_RCC_STB          RCC_APB2Periph_GPIOC
#define      TM1668_STB_PORT         GPIOC
#define      TM1668_STB_PIN          GPIO_Pin_15
void SPECIAL_PIN_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO | RCC_APB2Periph_GPIOB , ENABLE);
  GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable,ENABLE);
  TM1668_APBxClock_FUN(TM1668_RCC_DIO|RCC_APB2Periph_AFIO,ENABLE);
  BKP_TamperPinCmd(DISABLE);
  RCC_LSEConfig(RCC_LSE_OFF);	 		
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  GPIO_InitStructure.GPIO_Pin = TM1668_CLK_PIN|TM1668_STB_PIN;
  GPIO_Init(TM1668_DIO_PORT, &GPIO_InitStructure);       
}
 

