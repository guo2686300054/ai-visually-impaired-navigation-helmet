#include "show.h"
#include "sys.h"
#include "delay.h"
#include "oled.h"
void page_one()//��������
{
	OLED_Clear();
	OLED_ShowCHinese(0,0,0);OLED_ShowCHinese(16,0,1);OLED_ShowCHinese(32,0,2);OLED_ShowCHinese(48,0,3);//�ϰ�����	
	OLED_ShowCHinese(0,2,4);OLED_ShowCHinese(16,2,5);OLED_ShowCHinese(32,2,6);OLED_ShowCHinese(48,2,7);//������
	OLED_ShowCHinese(0,4,10);OLED_ShowCHinese(16,4,11);OLED_ShowCHinese(32,4,12);OLED_ShowCHinese(48,4,13);//��ǰ����
	OLED_ShowCHinese(0,6,10);OLED_ShowCHinese(16,6,11);OLED_ShowCHinese(32,6,14);OLED_ShowCHinese(48,6,15);//��ǰ����

	OLED_ShowString(64,0,":000.0cm",16);
	OLED_ShowString(64,2,":       ",16);
	OLED_ShowString(64,4,":000.0*C",16);
	OLED_ShowString(64,6,":  000  ",16);
}

void page_two()
{
	OLED_Clear();
	OLED_ShowCHinese(0,0,16);OLED_ShowCHinese(16,0,17);OLED_ShowCHinese(32,0,22);OLED_ShowCHinese(48,0,23);//����״̬	
	OLED_ShowCHinese(0,2,28);OLED_ShowCHinese(16,2,29);OLED_ShowCHinese(32,2,30);OLED_ShowCHinese(48,2,31);//����ǿ��
	OLED_ShowCHinese(0,4,10);OLED_ShowCHinese(16,4,11);OLED_ShowCHinese(32,4,34);OLED_ShowCHinese(48,4,36);//��ǰ����
	OLED_ShowCHinese(0,6,10);OLED_ShowCHinese(16,6,11);OLED_ShowCHinese(32,6,35);OLED_ShowCHinese(48,6,36);//��ǰγ��
	OLED_ShowString(64,0,":       ",16);
	OLED_ShowString(64,2,":0000Lux",16);
  OLED_ShowString(64,4,":   .   ",16);
	OLED_ShowString(64,6,":   .   ",16);
}

void page_three() 
{
	OLED_Clear();
	OLED_ShowCHinese(32,0,0);OLED_ShowCHinese(48,0,1);OLED_ShowCHinese(64,0,32);OLED_ShowCHinese(80,0,33);//�ϰ���ֵ	

	OLED_ShowString(44,4,"000cm",16);
}

void page_four() 
{
	OLED_Clear();
	OLED_ShowCHinese(32,0,28);OLED_ShowCHinese(48,0,29);OLED_ShowCHinese(64,0,32);OLED_ShowCHinese(80,0,33);//������ֵ	

	OLED_ShowString(36,4,"0000Lux",16);
}


